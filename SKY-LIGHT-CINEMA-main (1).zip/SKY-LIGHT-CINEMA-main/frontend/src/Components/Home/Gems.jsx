/* eslint-disable no-unused-vars */
import React from 'react'
import Header from '../Navbar/Navbar'
import Footer from '../Footer/Footer'
function Gems() {
  return (
    <div>
    <Header/>
      <h1>Gems</h1>
    <Footer/>
    </div>
  )
}

export default Gems
