/* eslint-disable no-unused-vars */
import React from 'react'

function SupportDetails() {
  return (
    <div>
      
    </div>
  )
}

export default SupportDetails
